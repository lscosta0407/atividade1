const { MongoClient } = require('mongodb');
//parâmetros de conexão
const URL = "mongodb://127.0.0.1:27017";
const DB_NAME = "todo";
const COLLECTION_NAME = "tarefas";
let conexao = null;

async function conectar(){
    if(conexao) return conexao;

    try{
        const client = new MongoClient(URL);
        await client.connect();//await - espera assíncrona
        conexao = client.db(DB_NAME);
        return conexao;
    }catch(erro){
        console.error(erro);
    }
}


async function listar(){
    try{
        const db = await conectar();
        return await db.collection(COLLECTION_NAME).find().toArray();
    }catch(erro){
        throw new Error(erro);
    }
}

//para exportar o módulo para uso
module.exports = { listar }