var express = require('express');
var router = express.Router();
const db = require('../dao/todo-db');

//rota para listar as tarefas cadastradas
router.get('/tarefas/listar',async(req,res)=>{
  try{
    const registros = await db.listar();//uso a função assincrona listar de todo-db.js
    res.status(200).json(registros);
  }catch(erro){
    console.error(erro);
    res.status(500).json({mensagem: "Erro ao listar os registros."});
  }
});

//NUNCA APAGUE ESTA LINHA!!!
module.exports = router;
